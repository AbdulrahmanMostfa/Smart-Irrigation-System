package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import com.example.myapplication.ml.SoilMoisture97;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.IOException;

public class PumbActivity extends AppCompatActivity {

    EditText edt1 ,edt2;
    Button bt1;
    TextView tx;
    float[] array = new float[2];
    int j;
    String[] results = {"DON'T IRRIGATE","IRRIGATE"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pumb);

            edt1 = findViewById(R.id.ed1);
            edt2 = findViewById(R.id.ed2);
            tx = findViewById(R.id.textpump);



        Spinner spinner1 = findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.crop, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Object item = adapterView.getItemAtPosition(i);


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }


        });

        String crop = spinner1.getSelectedItem().toString();
        if(crop=="cotton"){j=0;}

        bt1 =findViewById(R.id.buttonpump);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    float f1 = Float.parseFloat(edt1.getText().toString());
                    float f2 = Float.parseFloat(edt2.getText().toString());


                    array[0] = f1;
                    array[1] = f2;

                    try {
                        SoilMoisture97 model = SoilMoisture97.newInstance(getApplicationContext());

                        // Creates inputs for reference.
                        TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 2}, DataType.FLOAT32);
                        //inputFeature0.loadBuffer(byteBuffer);
                        inputFeature0.loadArray(array);

                        // Runs model inference and gets result.
                        SoilMoisture97.Outputs outputs = model.process(inputFeature0);
                        TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();
                        int x =getresult(outputFeature0.getFloatArray());
                        tx.setText(results[x]);
                        // Releases model resources if no longer used.
                        model.close();
                    } catch (IOException e) {
                        // TODO Handle the exception
                    }

                }catch (NumberFormatException e) {
                    Toast.makeText(PumbActivity.this,
                            "INVALID VALUES", Toast.LENGTH_LONG).show();
                    tx.setText(" ");

                }

            }
        });
    }
    int getresult(float[] x) {
        if (x[0] > 0.5) return 1;
        else return 0;
    }
}