package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.ml.Droughtmodel;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


public class soilActivity extends AppCompatActivity {


    private static final int READ_CODE=41;

    Button bt1;
    TextView tx;
    float[] array =new float[49];
    String str="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soil);

        bt1=findViewById(R.id.bot1);
        tx = findViewById(R.id.tsoil);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(intent, READ_CODE);

            }



        });


    }
    Uri file=null;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==READ_CODE){
            if(data !=null) {
                file = data.getData();
                try {
                    array=readfile(file);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    Droughtmodel model = Droughtmodel.newInstance(getApplicationContext());

                    // Creates inputs for reference.
                    TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 49}, DataType.FLOAT32);
                    inputFeature0.loadArray(array);

                    // Runs model inference and gets result.
                    Droughtmodel.Outputs outputs = model.process(inputFeature0);
                    TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();
                    str = getlevel(outputFeature0.getFloatArray());
                    tx.setText(str);

                    // Releases model resources if no longer used.
                    model.close();
                } catch (IOException e) {
                    // TODO Handle the exception
                }

            }

        }
    }

    private float[] readfile(Uri uri)throws Exception{
        InputStream inputStream= getContentResolver().openInputStream(uri);
        BufferedReader br=new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder sb=new StringBuilder();
        String line="";
        float[] c=new float[49];

        while((line=br.readLine())!=null){
            String[] row = line.split(",");
            for (int i = 0; i < c.length; i++) {

                c[i] = Float.parseFloat(row[i].toString());
            }
        }
        inputStream.close();
        return c;
    }







        //get result to the model
    String getlevel(float[]array){
        String[] level={"D0 : No Drought "," D1 : Abnormally Dry ","D2 : Moderate Drought ","D3 : SeverDrought "
        ,"D4 : Extreme Drought","D5 : Exceptional Drought"};
        int x=0;
        for(int i=0;i< array.length;i++){
            if (array[x]<array[i]){
                x=i;
            }

        }
        String s=level[x];

        return s;
    }

}


