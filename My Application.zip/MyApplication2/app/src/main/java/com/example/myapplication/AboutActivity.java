package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.widget.ImageView;
import android.widget.TextView;

public class AboutActivity extends AppCompatActivity {


    TextView tx1 ,tx2 ,tx3 ,tx4 ,tx5 ,tx6 ,tx7 ,tx8;
    ImageView png1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        tx1 = findViewById(R.id.tx1);
        tx2 = findViewById(R.id.tx2);
        tx3 = findViewById(R.id.tx3);
        tx4 = findViewById(R.id.tx4);
        tx5 = findViewById(R.id.tx5);
        tx6 = findViewById(R.id.tx6);
        tx7 = findViewById(R.id.tx7);
        tx8 =findViewById(R.id.tx8);
        png1=findViewById(R.id.image2);

        //name of each model
        String r = "Rain prediction:";
        tx1.setText(r);

        String r1 ="A forecast of rain and its precipitation, its aim is to help the client to organize the irrigation process, since if there is rain, he does not irrigate, and vice versa in the absence of rain.";
        String r2 = "The method of work: \n " +
                "This model works by inserting some data by the client, and based on it, the process of forecasting and determining the rate of precipitation, and the elements used (inputs) are: \n\n" +
                "1-Minimum Temperature \n" +
                "2- Maximum temperature \n" +
                "3- Wind Speed at (9AM) \n" +
                "4-Wimd Speed at (3PM) \n" +
                "5-Relative Humidity (9AM) \n" +
                "6-Relative Humidity (3PM) \n" +
                "7-Pressure at (9AM) \n" +
                "8-Pressure at (3PM) \n" +
                "9-Clouds at (9AM) \n" +
                "10-Clouds at (3PM) \n" +
                "11-Temperature at (9AM) \n" +
                "12-Temperature at (3PM) \n" +
                "13-Rainfall in mm \n \n" +
                "The output: \n" +
                "Based on these (inputs), we produce (outputs) with (yes) in case of rain, and (no) in case of no rain \n";
        tx2.setText(r1+"\n\n"+r2);
        String c = "Crop recommendation:";
        tx3.setText(c);
        String c1 = "Choosing the appropriate crop to plant in the soil depending on the weather and the contents of the soil \n\n"
                +"The method of work : \n" +
                "It works by inserting some data by the client based on it , the process of crop recommending and the elements used (inputs) are : \n\n" +
                "1- Ratio of nitrogen content in soil \n" +
                "2- Ratio of phosphorous content in soil \n" +
                "3- Ratio of potassium content in soil \n" +
                "4- Temperature \n" +
                "5- Percentage of relative humidity \n" +
                "6- Ph. Value of the soil \n" +
                "7- The amount of rainfall \n\n" +
                "The output : \n" +
                "When the users plug in this information (inputs) in the crop recommending section , it provides them with the percentage of the crops that can be planted in this type of soil (outputs)";
        tx4.setText(c1);
        String w = "Watering crops:";
        tx5.setText(w);
        String w1 = "Issuing a notification that this plant needs watering or not, and this process is done in the program by inserting certain data from a client and this data (input) is:\n\n" +
                "1- Crop\n" +
                "2- Temperature\n" +
                "3- Soil moisture\n\n" +
                "The output:\n" +
                "After entering the data and pressing RUN, it displays a message with (yes) if it needs irrigation, and (no) if it does not need irrigation.";
        tx6.setText(w1);
        String d = "Drought level:";
        tx7.setText(d);
        String d1 = "This is a classification of six levels of drought, Recognizing drought before it intensifies can reduce impacts and save money. \n\n" +
                "The method of work:\n" +
                "This model works by choosing a sample file by the client, and based on it, the process of classification is done, and the elements used (inputs) are soil data accompanied by meteorological indicators:\n" +
                "Soil data:\n" +
                "1- CULTIR_LAND\n" +
                "2- CULTRF_LAND\n" +
                "3- CULT_LAND\n" +
                "4- FOR_LAND\n" +
                "5- GRS_LAND\n" +
                "6- NVG_LAND\n" +
                "7- URB_LAND\n" +
                "8- WAT_LAND\n" +
                "9- Four directions aspect\n" +
                "10- Unknown direction aspect\n" +
                "11- Median elevation\n" +
                "12- Latitude\n" +
                "13- Longitude\n" +
                "14- 8 Slopes\n" +
                "15- 7 SQs\n\n" +
                "Meteorological indicators:\n" +
                "1- Precipitation (mm day-1)\n" +
                "2- Surface Pressure (kPa)\n" +
                "3- Specific Humidity at 2 Meters (g/kg)\n" +
                "4- Temperature at 2 Meters (C)\n" +
                "5- Dew/Frost Point at 2 Meters (C)\n" +
                "6- Wet Bulb Temperature at 2 Meters (C)\n" +
                "7- Maximum Temperature at 2 Meters (C)\n" +
                "8- Minimum Temperature at 2 Meters (C)\n" +
                "9- Temperature Range at 2 Meters (C)\n" +
                "10- Earth Skin Temperature (C)\n" +
                "11- Wind Speed at 10 Meters (m/s)\n" +
                "12- Maximum Wind Speed at 10 Meters (m/s)\n" +
                "13- Minimum Wind Speed at 10 Meters (m/s)\n" +
                "14- Wind Speed Range at 10 Meters (m/s)\n" +
                "15- Wind Speed at 50 Meters (m/s)\n" +
                "16- Maximum Wind Speed at 50 Meters (m/s)\n" +
                "17- Minimum Wind Speed at 50 Meters (m/s)\n" +
                "18- Wind Speed Range at 50 Meters (m/s)\n\n" +
                "The output:\n" +
                "Based on these (inputs), drought level is classified into six categories (First level is when the score equals 0 that means 'No drought'):";
        tx8.setText(d1);

    }
}