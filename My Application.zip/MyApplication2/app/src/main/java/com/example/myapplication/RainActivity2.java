package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.ml.Cropmodel;
import com.example.myapplication.ml.Rainfall;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.IOException;
import java.nio.ByteBuffer;
public class RainActivity2 extends AppCompatActivity  {
    EditText edt1, edt2, edt3, edt4, edt5, edt6, edt7, edt8, edt9, edt10, edt11, edt12, edt13;
    TextView tx;
    Button bt1;
    int j;
    float[] array = new float[14];
    String[] results = {"NO","YES"};

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rain2);
        edt1 = findViewById(R.id.edittext1);
        edt2 = findViewById(R.id.edittext2);
        edt3 = findViewById(R.id.edittext3);
        edt4 = findViewById(R.id.edittext4);
        edt5 = findViewById(R.id.edittext5);
        edt6 = findViewById(R.id.edittext6);
        edt7 = findViewById(R.id.edittext7);
        edt8 = findViewById(R.id.edittext8);
        edt9 = findViewById(R.id.edittext9);
        edt10 = findViewById(R.id.edittext10);
        edt11 = findViewById(R.id.edittext11);
        edt12 = findViewById(R.id.edittext12);
        edt13 = findViewById(R.id.edittext13);
        tx = findViewById(R.id.textrain);

        Spinner spinner1 = findViewById(R.id.spinner3);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.numbers, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Object item = adapterView.getItemAtPosition(i);
               // if(adapterView.getItemAtPosition(i).equals("Yes")){
                   // Toast.makeText(RainActivity2.this,
                           // "Yes", Toast.LENGTH_LONG).show();

                //}else {
                   // Toast.makeText(RainActivity2.this,
                     //   "No", Toast.LENGTH_LONG).show();

                //}

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        String rain = spinner1.getSelectedItem().toString();

        if(rain=="Yes"){j=1;}
        else {j=0;}


        //spinner1.setOnItemSelectedListener(this);


        bt1 = findViewById(R.id.buttonrain);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {


                    float f1 = Float.parseFloat(edt1.getText().toString());
                    float f2 = Float.parseFloat(edt2.getText().toString());
                    float f3 = Float.parseFloat(edt3.getText().toString());
                    float f4 = Float.parseFloat(edt4.getText().toString());
                    float f5 = Float.parseFloat(edt5.getText().toString());
                    float f6 = Float.parseFloat(edt6.getText().toString());
                    float f7 = Float.parseFloat(edt7.getText().toString());
                    float f8 = Float.parseFloat(edt8.getText().toString());
                    float f9 = Float.parseFloat(edt9.getText().toString());
                    float f10 = Float.parseFloat(edt10.getText().toString());
                    float f11 = Float.parseFloat(edt11.getText().toString());
                    float f12 = Float.parseFloat(edt12.getText().toString());
                    float f13 = Float.parseFloat(edt13.getText().toString());


                    array[0] = f1;
                    array[1] = f2;
                    array[2] = f4;
                    array[3] = f5;
                    array[4] = f6;
                    array[5] = f7;
                    array[6] = f8;
                    array[7] = f9;
                    array[8] = f10;
                    array[9] = f11;
                    array[10] = f12;
                    array[11] = f13;
                    array[12] = f3;
                    array[13] = j ;

                    try {
                        Rainfall model = Rainfall.newInstance(getApplicationContext());

                        // Creates inputs for reference.
                        TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 14}, DataType.FLOAT32);
                        //inputFeature0.loadBuffer(byteBuffer);
                        inputFeature0.loadArray(array);

                        // Runs model inference and gets result.
                        Rainfall.Outputs outputs = model.process(inputFeature0);
                        TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();
                        int x =getresult(outputFeature0.getFloatArray());
                        tx.setText(results[x]);



                        // Releases model resources if no longer used.
                        model.close();
                    } catch (IOException e) {
                        // TODO Handle the exception
                    }



                } catch (NumberFormatException e) {
                    Toast.makeText(RainActivity2.this,
                            "INVALID VALUES", Toast.LENGTH_LONG).show();
                    tx.setText(" ");

                }



            }
        });

    }
    int getresult(float[] x){
        if(x[0]>0.5)return 1;
        else return 0;
    }




}


