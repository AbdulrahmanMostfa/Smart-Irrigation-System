package com.example.myapplication;

import static java.lang.Math.round;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.ml.Cropmodel;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.IOException;
import java.nio.ByteBuffer;

public class CropActivity extends AppCompatActivity {
    EditText edt1, edt2, edt3, edt4, edt5, edt6, edt7;
    TextView tx;
    Button bt1;
    float[] array = new float[7];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop);
        edt1 = findViewById(R.id.edittext1);
        edt2 = findViewById(R.id.edittext2);
        edt3 = findViewById(R.id.edittext3);
        edt4 = findViewById(R.id.edittext4);
        edt5 = findViewById(R.id.edittext5);
        edt6 = findViewById(R.id.edittext6);
        edt7 = findViewById(R.id.edittext7);
        tx = findViewById(R.id.textcrop);
        bt1 = findViewById(R.id.buttoncrop);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {


                    float f1 = Float.parseFloat(edt1.getText().toString());
                    float f2 = Float.parseFloat(edt2.getText().toString());
                    float f3 = Float.parseFloat(edt3.getText().toString());
                    float f4 = Float.parseFloat(edt4.getText().toString());
                    float f5 = Float.parseFloat(edt5.getText().toString());
                    float f6 = Float.parseFloat(edt6.getText().toString());
                    float f7 = Float.parseFloat(edt7.getText().toString());


                    array[0] = f1;
                    array[1] = f2;
                    array[2] = f3;
                    array[3] = f4;
                    array[4] = f5;
                    array[5] = f6;
                    array[6] = f7;

                    try {

                        Cropmodel model = Cropmodel.newInstance(getApplicationContext());

                        // Creates inputs for reference.
                        TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 7}, DataType.FLOAT32);
                        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(7 * 7);
                        //inputFeature0.loadBuffer(byteBuffer);


                        inputFeature0.loadArray(array);


                        // Runs model inference and gets result.
                        Cropmodel.Outputs outputs = model.process(inputFeature0);
                        TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();
                        String x = getcrop(outputFeature0.getFloatArray());
                        tx.setText(x);
                        //Releases model resources if no longer used.
                        model.close();
                    } catch (IOException e) {
                        // TODO Handle the exception
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(CropActivity.this,
                            "INVALID VALUES", Toast.LENGTH_LONG).show();
                    tx.setText(" ");

                }


            }
        });

    }


    String getcrop(float[] arr) {
        int index = 0;

        String[] labels = {"Apple", "Banana", "Blackgram", "Chickpea", "Coconut", "Coffee", "Cotton", "Grapes", "Jute", "Kidneybeans", "Lentil", "Maize", "Mango", "Mothbeans", "Mungbean",
                "Muskmelon", "Orange", "Papaya", "Pigeonpeas", "Pomegranate", "Rice", "Watermelon"};
        String cropname[] = new String[3];

        for (int i = 0; i < 3; i++) {

            for (int j = 0; j < arr.length; j++) {
                if (arr[j] > arr[index])
                    index = j;
            }



            cropname[i] = labels[index];
            arr[index] = 0;
        }


        String x = "Highly recommended to be grown in this soil \n"+ "Firstly:  "+cropname[0] + "\n" +"Secondly:  "+ cropname[1] + "\n" +"Thirdly:  "+ cropname[2];
        return x;


    }
}

